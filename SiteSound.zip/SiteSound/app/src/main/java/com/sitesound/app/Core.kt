package com.sitesound.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class AudioItem(val uri: String, val name: String)

object Store {
    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("sitesound", Context.MODE_PRIVATE)

    fun links(c: Context): List<String> {
        val arr = JSONArray(prefs(c).getString("links", "[]"))
        return List(arr.length()) { arr.getString(it) }
    }

    fun saveLinks(c: Context, list: List<String>) {
        prefs(c).edit().putString("links", JSONArray(list).toString()).apply()
    }

    fun audios(c: Context): List<AudioItem> {
        val arr = JSONArray(prefs(c).getString("audios", "[]"))
        return List(arr.length()) {
            val o = arr.getJSONObject(it)
            AudioItem(o.getString("uri"), o.getString("name"))
        }
    }

    fun saveAudios(c: Context, list: List<AudioItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        prefs(c).edit().putString("audios", arr.toString()).apply()
    }

    fun stopOnLeave(c: Context): Boolean = prefs(c).getBoolean("stop_on_leave", false)

    fun setStopOnLeave(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("stop_on_leave", v).apply()
    }
}

/** Сравнение текста адресной строки браузера со списком ссылок. */
object Matcher {
    private fun strip(s: String): String =
        s.trim().lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.")

    private fun hostOf(t: String): String =
        t.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')

    private fun pathOf(t: String): String {
        val i = t.indexOf('/')
        return if (i < 0) "" else t.substring(i).trim('/')
    }

    /** Возвращает ключ найденной ссылки или null. */
    fun match(barText: String, links: List<String>): String? {
        val bar = strip(barText.substringBefore('\n').substringBefore(' '))
        val barHost = hostOf(bar)
        if (!barHost.contains('.')) return null
        val barPath = pathOf(bar)
        for (link in links) {
            val l = strip(link)
            val lHost = hostOf(l)
            if (lHost.isEmpty()) continue
            if (!(barHost == lHost || barHost.endsWith(".$lHost"))) continue
            val lPath = pathOf(l)
            // Chrome часто показывает только домен; путь сравниваем, только если он виден
            if (lPath.isNotEmpty() && barPath.isNotEmpty() && !barPath.startsWith(lPath)) continue
            return "$lHost/$lPath"
        }
        return null
    }
}

object Player {
    private var mp: MediaPlayer? = null
    private var last: String? = null

    fun playRandom(c: Context): Boolean {
        val list = Store.audios(c)
        if (list.isEmpty()) return false
        val pool = if (list.size > 1) list.filter { it.uri != last } else list
        val pick = pool.random()
        last = pick.uri
        return play(c, Uri.parse(pick.uri))
    }

    private fun play(c: Context, uri: Uri): Boolean {
        stop()
        return try {
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            m.setDataSource(c.applicationContext, uri)
            m.setOnPreparedListener { it.start() }
            m.setOnCompletionListener {
                it.release()
                if (mp === it) mp = null
            }
            m.setOnErrorListener { p, _, _ ->
                p.release()
                if (mp === p) mp = null
                true
            }
            mp = m
            m.prepareAsync()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        try {
            mp?.release()
        } catch (_: Exception) {
        }
        mp = null
    }
}
