package com.sitesound.app

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SiteWatcherService : AccessibilityService() {

    private var activeKey: String? = null
    private var lastCheck = 0L

    companion object {
        val BROWSERS = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
            "com.sec.android.app.sbrowser", "com.microsoft.emmx", "com.opera.browser",
            "com.opera.mini.native", "com.brave.browser", "com.yandex.browser",
            "com.vivaldi.browser", "com.duckduckgo.mobile.android", "com.kiwibrowser.browser"
        )
        private val ID_HINTS = listOf(
            "url_bar", "url_field", "location_bar_edit_text",
            "toolbar_url_view", "omnibar_address", "address_bar"
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return

        if (pkg !in BROWSERS) {
            // ушли из браузера в другое приложение -> "выход с сайта"
            if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                pkg != "com.android.systemui" && pkg != packageName
            ) leftSite()
            return
        }

        val now = SystemClock.uptimeMillis()
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && now - lastCheck < 120) return
        lastCheck = now

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val text = findUrl(root, pkg) ?: return

        val key = Matcher.match(text, Store.links(this))
        if (key == null) {
            leftSite()
        } else if (key != activeKey) {
            activeKey = key
            Player.playRandom(this)
        }
    }

    private fun leftSite() {
        if (activeKey != null) {
            activeKey = null
            if (Store.stopOnLeave(this)) Player.stop()
        }
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        val ids = listOf("url_bar", "location_bar_edit_text", "mozac_browser_toolbar_url_view", "url_field")
        for (id in ids) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")
            if (!nodes.isNullOrEmpty()) {
                val n = nodes[0]
                // пока пользователь печатает в адресной строке — ничего не делаем
                return if (n.isFocused) null else n.text?.toString()
            }
        }
        return scan(root, 0, intArrayOf(0))
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int, count: IntArray): String? {
        if (n == null || depth > 25 || count[0]++ > 600) return null
        val id = n.viewIdResourceName
        if (id != null && ID_HINTS.any { id.contains(it) }) {
            val t = n.text?.toString()
            if (!t.isNullOrBlank() && !n.isFocused) return t
        }
        for (i in 0 until n.childCount) {
            val r = scan(n.getChild(i), depth + 1, count)
            if (r != null) return r
        }
        return null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        Player.stop()
        super.onDestroy()
    }
}
