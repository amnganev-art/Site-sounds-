package com.sitesound.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var linkInput: EditText
    private lateinit var linksBox: LinearLayout
    private lateinit var audiosBox: LinearLayout
    private val reqAudio = 1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 18f, bold: Boolean = true) =
        TextView(this).apply {
            this.text = text
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(16), 0, dp(6))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("Сайт → Звук", 26f))

        statusView = TextView(this).apply { textSize = 15f }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "Открыть настройки специальных возможностей"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(label("Ссылки сайтов"))
        linkInput = EditText(this).apply {
            hint = "Вставь одну или несколько ссылок"
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(linkInput)
        root.addView(Button(this).apply {
            text = "Добавить ссылки"
            setOnClickListener { addLinks() }
        })
        linksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(linksBox)

        root.addView(label("Аудио (MP3)"))
        root.addView(Button(this).apply {
            text = "Добавить MP3 из памяти телефона"
            setOnClickListener { pickAudio() }
        })
        audiosBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(audiosBox)

        root.addView(label("Настройки"))
        root.addView(Switch(this).apply {
            text = "Останавливать звук, когда ушёл с сайта"
            isChecked = Store.stopOnLeave(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Store.setStopOnLeave(this@MainActivity, v) }
        })
        root.addView(Button(this).apply {
            text = "Проверить звук"
            setOnClickListener {
                if (!Player.playRandom(this@MainActivity))
                    Toast.makeText(this@MainActivity, "Сначала добавь MP3", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Остановить звук"
            setOnClickListener { Player.stop() }
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun serviceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun refresh() {
        statusView.text = if (serviceEnabled())
            "✅ Служба включена — можно заходить на сайты"
        else
            "⚠️ Служба выключена. Нажми кнопку ниже, найди «Сайт-звук» и включи."

        linksBox.removeAllViews()
        val links = Store.links(this)
        links.forEach { link ->
            linksBox.addView(row(link) {
                Store.saveLinks(this, Store.links(this).filter { it != link })
                refresh()
            })
        }

        audiosBox.removeAllViews()
        Store.audios(this).forEach { item ->
            audiosBox.addView(row(item.name) {
                Store.saveAudios(this, Store.audios(this).filter { it.uri != item.uri })
                refresh()
            })
        }
    }

    private fun row(text: String, onDelete: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        r.addView(
            TextView(this).apply { this.text = text; textSize = 15f },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        r.addView(Button(this).apply {
            this.text = "✕"
            setOnClickListener { onDelete() }
        })
        return r
    }

    private fun addLinks() {
        val tokens = linkInput.text.toString().split(Regex("\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return
        val cur = Store.links(this).toMutableList()
        tokens.forEach { if (it !in cur) cur.add(it) }
        Store.saveLinks(this, cur)
        linkInput.setText("")
        refresh()
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, reqAudio)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqAudio || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        data.data?.let { uris.add(it) }
        val cur = Store.audios(this).toMutableList()
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            if (cur.none { it.uri == u.toString() }) cur.add(AudioItem(u.toString(), displayName(u)))
        }
        Store.saveAudios(this, cur)
        refresh()
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        } catch (_: Exception) {
        }
        return u.lastPathSegment ?: "audio"
    }
}
